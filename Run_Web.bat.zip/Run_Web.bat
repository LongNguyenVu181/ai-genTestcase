@echo off
title QA Agent Streamlit UI
cd /d "%~dp0"
".\venv\Scripts\python.exe" -m streamlit run multiAgent.py
pause